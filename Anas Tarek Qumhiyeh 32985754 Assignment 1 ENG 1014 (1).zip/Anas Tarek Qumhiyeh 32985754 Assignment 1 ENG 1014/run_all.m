% run_all.m
clear all; close all; clc; fclose all;

%% do not modify any part of this file!
% it runs each part individually
% there should be no intervention from the user
% students will lose marks if this file does not run properly

%% Question 1a
Q1a;

%% Question 1b
Q1b;

%% Question 1c
Q1c;

%% Question 2a
Q2a;

%% Question 2b
Q2b;

%% Question 2c
Q2c;