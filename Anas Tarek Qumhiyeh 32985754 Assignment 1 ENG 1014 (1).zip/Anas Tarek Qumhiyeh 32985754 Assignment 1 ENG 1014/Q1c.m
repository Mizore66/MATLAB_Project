% Q1c

% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Anas Tarek Qumhiyeh
% ID   : 32985754
% Date Modified : 5/20/2022

fprintf('\n Q1c \n\n')
%%
%Add your code here
pop_data = importdata("Population_data.xlsx");
poplocation = pop_data.textdata(2:end,2);
popmill = pop_data.data;
check = 0;
country_count = 1;

[AsiaPop_mill,AfricaPop_mill,NorthAmericaPop_mill,SouthAmericaPop_mill,OceaniaPop_mill,EuropePop_mill] = deal(0,0,0,0,0,0);

for a = 1:length(Total_Deaths)
    for n = country_count:length(poplocation)
        if strcmp(poplocation(n),Location(a)) == 1
            if strcmp(Continent(a),'Asia') == 1
                AsiaPop_mill = AsiaPop_mill + popmill(n);
            end
            if strcmp(Continent(a),'Africa') == 1
                AfricaPop_mill = AfricaPop_mill + popmill(n);
            end
            if strcmp(Continent(a),'North America') == 1
                NorthAmericaPop_mill = NorthAmericaPop_mill + popmill(n);
            end
            if strcmp(Continent(a),'South America') == 1
                SouthAmericaPop_mill = SouthAmericaPop_mill + popmill(n);
            end
            if strcmp(Continent(a),'Europe') == 1
                EuropePop_mill = EuropePop_mill + popmill(n);
            end
            if strcmp(Continent(a),'Oceania') == 1
                OceaniaPop_mill = OceaniaPop_mill + popmill(n);
            end
            country_count = country_count + 1;
            break
        end
    end
end

Case_perMillion = [AfricaCases(end)/AfricaPop_mill, AsiaCases(end)/AsiaPop_mill,EuropeCases(end)/EuropePop_mill,SouthAmericaCases(end)/SouthAmericaPop_mill,NorthAmericaCases(end)/NorthAmericaPop_mill,OceaniaCases(end)/OceaniaPop_mill];
Death_perMillion = [AfricaDeaths(end)/AfricaPop_mill, AsiaDeaths(end)/AsiaPop_mill,EuropeDeaths(end)/EuropePop_mill,SouthAmericaDeaths(end)/SouthAmericaPop_mill,NorthAmericaDeaths(end)/NorthAmericaPop_mill,OceaniaDeaths(end)/OceaniaPop_mill];

for n = 1:6
    Rank_case(n) = 1;
    Rank_death(n) = 1;
    for m = 1:6
       if Case_perMillion(n)< Case_perMillion(m)
           Rank_case(n) = Rank_case(n) + 1;
       end
       if Death_perMillion(n)< Death_perMillion(m)
           Rank_death(n) = Rank_death(n) + 1;
       end
    end
end

%i.)
world_map_case = imread("world_map.bmp");
for row_index = 1:size(world_map_case,1)
    for column_index = 1:size(world_map_case,2)
        if world_map_case(row_index,column_index) == 0
            continue
        end
            world_map_case(row_index,column_index) = (255/6)*(7-Rank_case(world_map_case(row_index,column_index)));
    end
end

%ii.)
world_map_death = imread("world_map.bmp");
for row_index = 1:size(world_map_death,1)
    for column_index = 1:size(world_map_death,2)
        if world_map_death(row_index,column_index) == 0
            continue
        end
            world_map_death(row_index,column_index) = (255/6)*(7-Rank_death(world_map_death(row_index,column_index)));
    end
end

%Print results

%You should have produced one figure window by the end of this task.
figure(2)
subplot(2,1,1) 
imshow(world_map_case)
title('Shading the world map based on their ratio of amount of CovidCasePerMillion')

subplot(2,1,2)
imshow(world_map_death)
title('Shading the world map based on their ratio of amount of CovidDeathPerMillion')
